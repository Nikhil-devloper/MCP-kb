declare const app: import("express-serve-static-core").Express;
export default app;
