import serverless from 'serverless-http';
export declare const handler: serverless.Handler;
